
/* ========================================================================
 *
 * ======================================================================== */
(function(){
    //$(window).resize(function(){autoHeight();});
   // autoHeight();
    /*function autoHeight(){
        var height= $(document.body).height()-$("#top_header").height();
        $("#right_frame").height(height);
        console.log(height);
    }*/
    $("#folded_menu").click(function(){
        var main = $("#mainbody");
        if($("#mainbody").hasClass("folded")){
            $(".main-container").removeClass("folded");
        }else{
            $(".main-container").addClass("folded");
            $(".menu .submenu").slideUp();
        }
    });

    var mianMenu = {
        init:function(){
            var li = $(".mainmenu li"),menu = $(".mainmenu");
            menu.on('click', '.opensub', function(){
                var a = $(this).parent();
                if(a.hasClass('open')){
                    a.removeClass('open');
                    a.find(".submenu").slideUp();
                }else{
                    li.removeClass('open');
                    $(".mainmenu .submenu").slideUp();
                    a.addClass('open');
                    a.find(".submenu").slideDown();
                }

            });

            menu.on('click', '.iframeurl', function(event){
                event.preventDefault();
                var _this = $(this);
                if(_this.parent().hasClass('active')){
                    return;
                }else{
                    li.removeClass('active');
                    _this.parent().addClass('active');
                   /* var rightFrame = $("#right_frame");
                    rightFrame.attr("src",_this.attr("href"));*/
                   var titles = _this.find("span").text();
                    var hrefs = _this.attr("href");
                    $('#right_tab').tabs('add',{
                        title: titles,
                        content:'<iframe  src="'+ hrefs+'" width="100%" height="100%" name="iframe" scrolling="no" frameborder="0"></iframe>',
                        closable:true,
                        tools:[{
                            iconCls:'icon-mini-refresh',
                            handler:function(){
                                //alert('refresh');
                            }
                        }]
                    });
                }
            });
        }
    };

    mianMenu.init();
})();